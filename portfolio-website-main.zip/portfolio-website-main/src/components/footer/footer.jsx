import React from 'react'

function Footer() {
    return (
        <>
            <footer>
                © 2023 Oran wiriya. All Rights Reserved.
            </footer>
        </>
    )
}

export default Footer